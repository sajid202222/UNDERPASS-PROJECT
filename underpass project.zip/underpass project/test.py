from twilio.rest import Client

# Twilio credentials
ACCOUNT_SID = 'AC5b86b6b13bd2fab053f8a78874bb25c8'
AUTH_TOKEN = '04aa638d6f8496145dfaff2146c8899b'
TWILIO_PHONE_NUMBER = '+18155154811'  # Your Twilio phone number
TO_PHONE_NUMBER = '+917338631971'     # Destination phone number

# Initialize Twilio client
client = Client(ACCOUNT_SID, AUTH_TOKEN)

def send_sms(alert_message):
    try:
        message = client.messages.create(
            body=alert_message,
            from_=TWILIO_PHONE_NUMBER,
            to=TO_PHONE_NUMBER
        )
        print(f"SMS sent: SID {message.sid}")
    except Exception as e:
        print(f"Failed to send SMS: {e}")

send_sms(f"Alert: Water level is high in the underpass! Distance:  cm")