import serial
from twilio.rest import Client

# Twilio credentials
ACCOUNT_SID = 'AC4855e7f5b9eb15db6ac3a9eb88c25610'
AUTH_TOKEN = '71b089397a1a95e9909b7020835374dc'
TWILIO_PHONE_NUMBER = '+16814413906'  # Your Twilio phone number
TO_PHONE_NUMBER = '+916361891120'     # Destination phone number

# GPS Coordinates of the underpass (replace with actual coordinates if available)
UNDERPASS_LAT = "12.9716"  # Latitude
UNDERPASS_LON = "77.5946"  # Longitude

# Initialize Twilio client
client = Client(ACCOUNT_SID, AUTH_TOKEN)

# Setup serial communication with Arduino
arduino = serial.Serial(port='COM3', baudrate=9600, timeout=1)  # Adjust port for your setup

# Flag to track whether SMS has been sent
sms_sent = False

def send_sms(alert_message):
    try:
        message = client.messages.create(
            body=alert_message,
            from_=TWILIO_PHONE_NUMBER,
            to=TO_PHONE_NUMBER
        )
        print(f"SMS sent: SID {message.sid}")
    except Exception as e:
        print(f"Failed to send SMS: {e}")

print("Listening for alerts...")

while True:
    if arduino.in_waiting > 0:
        # Read and decode the data from Arduino
        line = arduino.readline().decode('utf-8').strip()
        print(f"Received from Arduino: {line}")

        try:
            # Parse the distance value
            distance = float(line)

            # Check if the distance is less than 7 cm
            if distance <= 7:
                if not sms_sent:
                    alert_message = (
                        f"Alert: Water level is high in the underpass! "
                        f"Water Level: {distance} cm. "
                        f"Location: https://www.google.com/maps?q={UNDERPASS_LAT},{UNDERPASS_LON}"
                    )
                    send_sms(alert_message)
                    sms_sent = True  # Mark SMS as sent
            else:
                # Reset the flag if distance goes above threshold
                sms_sent = False

        except ValueError:
            print("Invalid data received; ignoring.")
