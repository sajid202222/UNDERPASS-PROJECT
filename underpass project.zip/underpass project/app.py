from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/underpasses')
def get_underpasses():
    underpasses = [
        {"name": "Underpass 1", "lat": 12.9716, "lng": 77.5946, "status": "Critical"},
        {"name": "Underpass 2", "lat": 12.2958, "lng": 76.6394, "status": "Safe"}
    ]
    return jsonify(underpasses)

if __name__ == '__main__':
    app.run(debug=True)
